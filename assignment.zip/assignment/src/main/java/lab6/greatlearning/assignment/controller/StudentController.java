package lab6.greatlearning.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lab6.greatlearning.assignment.entity.Student;
import lab6.greatlearning.assignment.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
    @RequestMapping("/list")
	public String listStudents(Model theModel) 
	{
    	List<Student> studentlist = studentService.findAll();
		theModel.addAttribute("students", studentlist);
		return "list-students";
		
	}
    
    @RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Student student = new Student();
		theModel.addAttribute("students", student);
		theModel.addAttribute("mode", "Add");
		return "student-form";

	}

    @RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("studentid") int studentid, Model theModel) {
		Student student = studentService.findById(studentid);
		theModel.addAttribute("students", student);
		theModel.addAttribute("mode", "Update");
		return "student-form";

	}

	@PostMapping("/save")
	public String saveStudent(
			@RequestParam(value = "studentid") int studentid,
			@RequestParam(value = "firstName") String firstname,
			@RequestParam(value= "lastName") String lastname,
			@RequestParam(value = "course") String course,
			@RequestParam(value = "country") String country) {
		
		Student student=null;
		
		if(studentid==0) {
			 student=new Student(firstname, lastname, course, country);
		}
		else {
			student=studentService.findById(studentid);
			student.setFirstName(firstname);
			student.setLastName(lastname);
			student.setCourse(course);
			student.setCountry(country);
		}
		studentService.save(student);
		return "redirect:/student/list";
		
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam("studentid") int studentid) {
		studentService.deleteById(studentid);
		return "redirect:/student/list";
		
	}
	
	@RequestMapping("/403")
	public String showErrorPgae() {
		return "403";
		
	}
}
